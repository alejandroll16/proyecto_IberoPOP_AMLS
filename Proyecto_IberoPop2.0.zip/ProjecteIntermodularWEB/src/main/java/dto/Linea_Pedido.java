/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dto;

import java.util.Objects;

/**
 *
 * @author ciclost
 */
public class Linea_Pedido {
    
    private Productos producto;
    private Pedido pedido;
    private int cantidad;
    private double precioProducto;

    public Linea_Pedido(Productos producto, int cantidad, double precioProducto) {
        this.producto = producto;
        this.cantidad = cantidad;
        this.precioProducto = precioProducto;
    }

    public Linea_Pedido(Productos producto, Pedido pedido, int cantidad, double precioProducto) {
        this.producto = producto;
        this.pedido = pedido;
        this.cantidad = cantidad;
        this.precioProducto = precioProducto;
    }

    public Productos getProducto() {
        return producto;
    }

    public Pedido getPedido() {
        return pedido;
    }

    public int getCantidad() {
        return cantidad;
    }

    public double getPrecioProducto() {
        return precioProducto;
    }

    public void setProducto(Productos producto) {
        this.producto = producto;
    }

    public void setPedido(Pedido pedido) {
        this.pedido = pedido;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public void setPrecioProducto(double precioProducto) {
        this.precioProducto = precioProducto;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 97 * hash + Objects.hashCode(this.producto);
        hash = 97 * hash + Objects.hashCode(this.pedido);
        hash = 97 * hash + this.cantidad;
        hash = 97 * hash + (int) (Double.doubleToLongBits(this.precioProducto) ^ (Double.doubleToLongBits(this.precioProducto) >>> 32));
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Linea_Pedido other = (Linea_Pedido) obj;
        if (this.cantidad != other.cantidad) {
            return false;
        }
        if (Double.doubleToLongBits(this.precioProducto) != Double.doubleToLongBits(other.precioProducto)) {
            return false;
        }
        if (!Objects.equals(this.producto, other.producto)) {
            return false;
        }
        return Objects.equals(this.pedido, other.pedido);
    }

    @Override
    public String toString() {
        return "Linea_Pedido{" + "producto=" + producto + ", pedido=" + pedido + ", cantidad=" + cantidad + ", precioProducto=" + precioProducto + '}';
    }

    
    
    
}
