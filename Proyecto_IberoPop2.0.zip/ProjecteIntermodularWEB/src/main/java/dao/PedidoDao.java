/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import dto.Direccion;
import dto.Pedido;
import dto.Productos;
import dto.TipoPago;
import dto.Usuario;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;



/**
 *
 * @author aleja
 */
public class PedidoDao extends TablaDAO<Pedido> {
    public PedidoDao() {
        this.tabla = "PROYECTO_pedido";
    }

    @Override
    public int actualizar(Pedido p) throws SQLException {
        //No necesario para el proyecto
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public int anyadir(Pedido p) throws SQLException {
        String sentenciaSQL = "INSERT INTO " + tabla + " VALUES(?,?,?,?,?,?)";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, p.getCodigo());
        prepared.setInt(3, p.getUsuario().getCodigo());
        Direccion numero_direct = p.getUsuario_direct();
        if (numero_direct == null) {prepared.setNull(2, java.sql.Types.INTEGER);
        } else prepared.setInt(2, numero_direct.getNumero());        
        prepared.setTimestamp(2, Timestamp.valueOf(p.getFecha()));
        prepared.setString(6, p.getTipo_pago().toString());
        int resultado = prepared.executeUpdate();
        anyadirLineas(p);
        return resultado;
        
        
    }

    @Override
    public Pedido eliminar(Pedido p) throws SQLException {
        if (p == null) {
            return null;
        } else {
            return eliminar(p.getCodigo()) != null ? p : null;
        }
    }

    @Override
    public boolean existe(Pedido p) throws SQLException {
        return existe(p.getCodigo());
    }

    @Override
    public ArrayList<Pedido> getAll() throws SQLException {
        ArrayList<Pedido> lista = new ArrayList<>();
        String sentenciaSQL = "SELECT * FROM " + tabla + " ORDER BY codigo";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            int codigo = resultSet.getInt("codigo");
            Usuario usuario = new UsuarioDao().getByCodigo(resultSet.getInt("usuario"));
            Direccion direccion = new DireccionDao().getByCodigo(resultSet.getInt("coddir"));
            LocalDateTime fecha = resultSet.getTimestamp("fecha").toLocalDateTime();
            TipoPago tipoPago = TipoPago.valueOf(resultSet.getString(" tipoPago,"));
            LinkedHashMap<Productos, Integer> lineasPedido = getLineas(codigo);
            lista.add(new Pedido(codigo, usuario, direccion, fecha,tipoPago, lineasPedido));
        }

        return lista;
    }

    @Override
    public Pedido getByCodigo(int codigo) throws SQLException {
        String sentenciaSQL = "SELECT * FROM " + tabla + " WHERE codigo=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, codigo);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            Usuario usuario = new UsuarioDao().getByCodigo(resultSet.getInt("usuario"));
            Direccion direccion = new DireccionDao().getByCodigo(resultSet.getInt("coddir"));
            LocalDateTime fecha = resultSet.getTimestamp("fecha").toLocalDateTime();
            TipoPago tipoPago = TipoPago.valueOf(resultSet.getString(" tipoPago,"));
            LinkedHashMap<Productos, Integer> lineasPedido = getLineas(codigo);
            return new Pedido(codigo, usuario, direccion, fecha,tipoPago, lineasPedido);
        }

        return null;
    }

    public ArrayList<Pedido> getByCodigoUsuario(int codigoUsuario) throws SQLException {
        ArrayList<Pedido> pedidos = new ArrayList<>();
        String sentenciaSQL = "SELECT * FROM " + tabla + " WHERE usuario=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, codigoUsuario);
        ResultSet resultSet = prepared.executeQuery();
        Usuario usuario = new UsuarioDao().getByCodigo(codigoUsuario);
        while (resultSet.next()) {
            int codigo = resultSet.getInt("codigo");
            Direccion direccion = new DireccionDao().getByCodigo(resultSet.getInt("coddir"));
            LocalDateTime fecha = resultSet.getTimestamp("fecha").toLocalDateTime();
            TipoPago tipoPago = TipoPago.valueOf(resultSet.getString(" tipoPago,"));
            LinkedHashMap<Productos, Integer> lineasPedido = getLineas(codigo);
            pedidos.add(new Pedido(codigo, usuario, direccion, fecha,tipoPago, lineasPedido));
        }

        return pedidos;
    }
    
    

    public LinkedHashMap<Productos, Integer> getLineas(int codPedido) throws SQLException {
        ProductosDao productosDao = new ProductosDao();
        LinkedHashMap<Productos, Integer> lineas = new LinkedHashMap<>();
        String sentenciaSQL = "SELECT producto, cantidad FROM PROYECTO_linea_pedido WHERE pedido = ?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, codPedido);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            Productos product = productosDao.getByCodigo(resultSet.getInt("producto"));
            int cantidad = resultSet.getInt("cantidad");
            lineas.put(product, cantidad);
        }

        return lineas;

    }

    private void anyadirLineas(Pedido p) throws SQLException {
        for (Map.Entry<Productos, Integer> entry : p.getLineasPedido().entrySet()) {
            String sentenciaSQL = "INSERT INTO productospedido VALUES(?, ?, ?)";
            PreparedStatement prepared = getPrepared(sentenciaSQL);
            prepared.setInt(1, entry.getKey().getCodigo());
            prepared.setInt(2, p.getCodigo());
            prepared.setInt(3, entry.getValue());
            prepared.executeUpdate();
        }
    }

    private void eliminarLineas(Pedido p) throws SQLException {
        String sentenciaSQL = "DELETE FROM PROYECTO_linea_pedido WHERE pedido=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, p.getCodigo());
        prepared.executeUpdate();

    }

    public boolean estaFacturado(int codpedido) throws SQLException {
        String sentenciaSQL = "SELECT * FROM factura WHERE pedido=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, codpedido);
        return prepared.executeUpdate() != 0;

    }
    
    
}
