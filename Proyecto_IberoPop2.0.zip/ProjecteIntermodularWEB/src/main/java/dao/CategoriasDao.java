/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import dto.Categorias;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.OptionalInt;

/**
 *
 * @author aleja
 */
public class CategoriasDao extends TablaDAO<Categorias> {
    
    public CategoriasDao() {
        this.tabla = "PROYECTO_CATEGORIAS";
    }

    @Override
    public int actualizar(Categorias c) throws SQLException {
        //No sería necesario al 100% pero lo dejo listo por si acaso·
        String sentenciaSQL = "UPDATE " + tabla + " SET nombre=? WHERE codigo=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, c.getCodigo());
        prepared.setString(2, c.getNombre());
        return prepared.executeUpdate();

    }

    @Override
    public int anyadir(Categorias c) throws SQLException {
        String sentenciaSQL = "INSERT INTO " + tabla + " VALUES(?,?)";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, c.getCodigo());
        prepared.setString(2, c.getNombre());
        return prepared.executeUpdate();

    }

    @Override
    public Categorias eliminar(Categorias c) throws SQLException{
        String sentenciaSQL = "DELETE FROM " + tabla + " WHERE codigo = ?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, c.getCodigo());
        return c;
    }

    @Override
    public boolean existe(Categorias c) throws SQLException{
        return existe(c.getCodigo());
    }

 
    @Override
    public ArrayList<Categorias> getAll() throws SQLException {
        ArrayList<Categorias> lista = new ArrayList<>();
        String sentenciaSQL = "SELECT * FROM " + tabla + " ORDER BY codigo";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            int codigo = resultSet.getInt("codigo");
            String nombre = resultSet.getString("nombre");
            lista.add(new Categorias(codigo, nombre));
        }
        
        return lista;
    }

    @Override
    public Categorias getByCodigo(int codigo) throws SQLException {
   String sentenciaSQL = "SELECT * FROM " + tabla + " WHERE codigo=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, codigo);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            String nombre = resultSet.getString("nombre");
            return new Categorias(codigo, nombre);
        }

        return null;
    }
    

    
    public OptionalInt getCodigoDe(String nombre) throws SQLException {
        String sentenciaSQL = "SELECT codigo FROM " + tabla + " WHERE nombre=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setString(1, nombre);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            return OptionalInt.of(resultSet.getInt("codigo"));
        }
        
        return OptionalInt.empty();
    }
    
    
    
    
}
