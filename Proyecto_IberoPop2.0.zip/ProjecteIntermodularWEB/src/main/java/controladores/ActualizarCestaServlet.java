/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controladores;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import dao.DireccionDao;
import dto.Direccion;
import dto.TipoPago;
import dto.Pedido;
import dto.Productos;
import dto.Usuario;

public class ActualizarCestaServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        HttpSession session = request.getSession();
        try (PrintWriter out = response.getWriter()) {
            Usuario usuarioSesion = (session != null && session.getAttribute("usuario") != null) ? (Usuario) session.getAttribute("usuario") : null;
            if (usuarioSesion == null || usuarioSesion.isAnonimo()) {
                out.println("<h2>No tienes permiso para acceder a esta sección</h2><p><a href=\"javascript: history.go(-1)\">Volver atrás</a></p>");

            } else if (session.getAttribute("cesta") == null) {
                response.sendRedirect("cesta.jsp");
            } else {
                Pedido carritoAnterior = (Pedido) session.getAttribute("cesta");
                LinkedHashMap<Productos, Integer> lineas = new LinkedHashMap<>(carritoAnterior.getLineasPedido());
                for (Map.Entry<Productos, Integer> linea : lineas.entrySet()) {
                    String strCodigo = String.valueOf(linea.getKey().getCodigo());
                    Integer nuevaCantidad = Integer.valueOf(request.getParameter(strCodigo));
                    if (nuevaCantidad > 0) {
                        lineas.put(linea.getKey(), nuevaCantidad);
                    }
                }
                TipoPago mp = TipoPago.valueOf(request.getParameter("TipoPago"));
                Direccion dir = new DireccionDao().getByCodigo(Integer.parseInt(request.getParameter("direccion")));
                Pedido cestaNueva = new Pedido(0,usuarioSesion, dir,LocalDateTime.MIN , mp,lineas);
                session.setAttribute("cesta", mp);
                response.sendRedirect("cesta.jsp");
            }
        } catch (SQLException ex) {
            System.out.println("Error SQL");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}