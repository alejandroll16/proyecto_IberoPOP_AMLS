/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dto;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;

/**
 *
 * @author ciclost
 */
public class Pedido {
    
    private int codigo;
    private Usuario usuario;
    private Direccion numero_direct;
    private LocalDateTime fecha;
    private TipoPago tipo_pago;
    private  LinkedHashMap<Productos,Integer> lineasPedido;
    

    public Pedido(int codigo, Usuario usuario, Direccion numero_direct, LocalDateTime fecha,  TipoPago tipo_pago, LinkedHashMap<Productos, Integer> lineasPedido) {
        this.codigo = codigo;
        this.usuario = usuario;
        this.numero_direct = numero_direct;
        this.fecha = fecha;
        this.tipo_pago = tipo_pago;
        this.lineasPedido = lineasPedido;
       
    }

    public int getCodigo() {
        return codigo;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public Direccion getUsuario_direct() {
        return numero_direct;
    }

    public LocalDateTime getFecha() {
        return fecha;
    }


    public TipoPago getTipo_pago() {
        return tipo_pago;
    }

   public LinkedHashMap<Productos, Integer> getLineasPedido() {
        return new LinkedHashMap<>(lineasPedido);
    }


    public double getPrecioTotal(){
     double total = 0;
     for(Map.Entry<Productos, Integer> entry: lineasPedido.entrySet()){
            total += entry.getValue() * entry.getKey().getPrecio();
     }
     return total;
    }
    
   
    @Override
    public int hashCode() {
        int hash = 5;
        hash = 47 * hash + this.codigo;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Pedido other = (Pedido) obj;
        return this.codigo == other.codigo;
    }

    @Override
    public String toString() {
        return "Pedido{" + "codigo=" + codigo + ", usuario=" + usuario + ", usuario_direct=" + numero_direct + ", fecha=" + fecha + ", tipo_pago=" + tipo_pago + ", lineasPedido=" + lineasPedido +  '}';
    }
    
     public boolean perteneceAUsuario(Usuario u){
        return this.usuario.equals(u);
    }

    
}
