/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import dto.Categorias;
import dto.Productos;
import dto.Usuario;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashSet;

/**
 *
 * @author ciclost
 */
public class ProductosDao extends TablaDAO<Productos> {

    public ProductosDao() {
        this.tabla = "PROYECTO_productos";
    }

    @Override
    public int actualizar(Productos p) throws SQLException {
        String sentenciaSQL = "UPDATE " + tabla + " SET categoria=?, usuario_crea=?, usuario_modifica=?, f_creac=?, f_ult_modificacion=?, nombre=?, imagen=?, precio=?, IVA=?, descrip_caract=? WHERE codigo=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, p.getCategoria().getCodigo());

        Usuario usuCrea = p.getCrea();
        if (usuCrea == null) {
            prepared.setNull(2, java.sql.Types.INTEGER);
        } else {
            prepared.setInt(2, usuCrea.getCodigo());
        }

        Usuario usuModifica = p.getModifica();
        if (usuModifica == null) {
            prepared.setNull(3, java.sql.Types.INTEGER);
        } else {
            prepared.setInt(3, usuModifica.getCodigo());
        }

        LocalDateTime fCreac = p.getF_Creac();
        if (fCreac == null) {
            prepared.setNull(4, java.sql.Types.TIMESTAMP);
        } else {
            prepared.setTimestamp(4, Timestamp.valueOf(fCreac));
        }

        LocalDateTime fUltModificacion = p.getF_ult_modificacion();
        if (fUltModificacion == null) {
            prepared.setNull(5, java.sql.Types.TIMESTAMP);
        } else {
            prepared.setTimestamp(5, Timestamp.valueOf(fUltModificacion));
        }

        prepared.setString(6, p.getNombre());
        prepared.setString(7, p.getImagen());
        prepared.setDouble(8, p.getPrecio());
        prepared.setDouble(9, p.getIVA());
        prepared.setString(10, p.getDescrip_Caracteristicas());
        prepared.setInt(11, p.getCodigo());

        return prepared.executeUpdate();
    }

    @Override
    public int anyadir(Productos p) throws SQLException {
        String sentenciaSQL = "INSERT INTO " + tabla + " VALUES(?,?,?,?,?,?,?,?,?,?,?)";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, p.getCodigo());
        Categorias categoria = p.getCategoria();
        if (categoria == null) {
            prepared.setNull(2, java.sql.Types.INTEGER);
        } else {
            prepared.setInt(2, categoria.getCodigo());
        }

        Usuario usuCrea = p.getCrea();
        if (usuCrea == null) {
            prepared.setNull(3, java.sql.Types.INTEGER);
        } else {
            prepared.setInt(3, usuCrea.getCodigo());
        }
        Usuario usuModifica = p.getModifica();
        if (usuModifica == null) {
            prepared.setNull(4, java.sql.Types.INTEGER);
        } else {
            prepared.setInt(4, usuModifica.getCodigo());
        }

        LocalDateTime FCreac = p.getF_Creac();
        if (FCreac == null) {
            prepared.setNull(5, java.sql.Types.TIMESTAMP);
        } else {
            prepared.setTimestamp(5, Timestamp.valueOf(FCreac));
        }

        LocalDateTime FMod = p.getF_ult_modificacion();
        if (FMod == null) {
            prepared.setNull(6, java.sql.Types.TIMESTAMP);
        } else {
            prepared.setTimestamp(6, Timestamp.valueOf(FMod));
        }

        prepared.setString(7, p.getNombre());
        prepared.setString(8, p.getImagen());
        prepared.setDouble(9, p.getPrecio());
        prepared.setDouble(10, p.getIVA());
        prepared.setString(11, p.getDescrip_Caracteristicas());

        return anyadir(p);

    }

    @Override
    public Productos eliminar(Productos p) throws SQLException {

        return null;
    }

    @Override
    public boolean existe(Productos p) throws SQLException {
        return false;
    }

    @Override
    public ArrayList<Productos> getAll() throws SQLException {
        ArrayList<Productos> lista = new ArrayList<>();
        String sentenciaSQL = "SELECT * FROM " + tabla + " ORDER BY codigo";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            int codigo = resultSet.getInt("codigo");
            Categorias categoria = new CategoriasDao().getByCodigo(resultSet.getInt("categoria"));
            String nombre = resultSet.getString("nombre");
            String imagen = resultSet.getString("imagen");
            double precio = resultSet.getDouble("precio");
            double iva = resultSet.getDouble("IVA");
            LocalDateTime fechaCreacion = resultSet.getTimestamp("f_creac").toLocalDateTime();
            LocalDateTime fechaModificacion = resultSet.getTimestamp("f_ult_modificacion").toLocalDateTime();
            String descripcion = resultSet.getString("descrip_caract");
            Usuario usuarioCrea = new UsuarioDao().getByCodigo(resultSet.getInt("usuario_crea"));
            Usuario usuarioModifica = new UsuarioDao().getByCodigo(resultSet.getInt("usuario_modifica"));

            lista.add(new Productos(codigo, categoria, nombre, imagen, precio, iva, fechaCreacion, fechaModificacion, descripcion, usuarioCrea, usuarioModifica));
        }
        return lista;
    }

    @Override
    public Productos getByCodigo(int codigo) throws SQLException {
        String sentenciaSQL = "SELECT * FROM " + tabla + " WHERE codigo=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, codigo);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            Categorias categoria = new CategoriasDao().getByCodigo(resultSet.getInt("categoria"));
            String nombre = resultSet.getString("nombre");
            String imagen = resultSet.getString("imagen");
            double precio = resultSet.getDouble("precio");
            double iva = resultSet.getDouble("IVA");
            LocalDateTime fechaCreacion = resultSet.getTimestamp("f_creac").toLocalDateTime();
            LocalDateTime fechaModificacion = resultSet.getTimestamp("f_ult_modificacion").toLocalDateTime();
            String descripcion = resultSet.getString("descrip_caract");
            Usuario usuarioCrea = new UsuarioDao().getByCodigo(resultSet.getInt("usuario_crea"));
            Usuario usuarioModifica = new UsuarioDao().getByCodigo(resultSet.getInt("usuario_modifica"));

            return new Productos(codigo, categoria, nombre, imagen, precio, iva, fechaCreacion, fechaModificacion, descripcion, usuarioCrea, usuarioModifica);
        }

        return null;
    }

    public ArrayList<Productos> getByCodigoCategoria(int codigoCategoria) throws SQLException {
        ArrayList<Productos> lista = new ArrayList<>();
        String sentenciaSQL = "SELECT P.*, C.nombre AS CATEGORIA FROM PROYECTO_productos P JOIN PROYECTO_categorias C ON P.categoria = C.codigo WHERE C.codigo = ?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, codigoCategoria);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            int codigo = resultSet.getInt("codigo");
            Categorias categoria = new CategoriasDao().getByCodigo(resultSet.getInt("categoria"));
            String nombre = resultSet.getString("nombre");
            String imagen = resultSet.getString("imagen");
            double precio = resultSet.getDouble("precio");
            double iva = resultSet.getDouble("IVA");
            LocalDateTime fechaCreacion = resultSet.getTimestamp("f_creac").toLocalDateTime();
            LocalDateTime fechaModificacion = resultSet.getTimestamp("f_ult_modificacion").toLocalDateTime();
            String descripcion = resultSet.getString("descrip_caract");
            Usuario usuarioCrea = new UsuarioDao().getByCodigo(resultSet.getInt("usuario_crea"));
            Usuario usuarioModifica = new UsuarioDao().getByCodigo(resultSet.getInt("usuario_modifica"));

            lista.add(new Productos(codigo, categoria, nombre, imagen, precio, iva, fechaCreacion, fechaModificacion, descripcion, usuarioCrea, usuarioModifica));
        }

        return lista;
    }

    public LinkedHashSet<Categorias> getCategoriasByCodProducto(int codProducto) throws SQLException {
        LinkedHashSet<Categorias> categorias = new LinkedHashSet<>();
        String sentenciaSQL = "SELECT ca.codigo, ca.nombre FROM categprodu cp, categoria ca WHERE ca.codigo = cp.categoria AND cp.producto = ?  ORDER BY ca.codigo";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, codProducto);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            int codigo = resultSet.getInt("codigo");
            String nombre = resultSet.getString("nombre");
            categorias.add(new Categorias(codigo, nombre));
        }
        return categorias;
    }

}
