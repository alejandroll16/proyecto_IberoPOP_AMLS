/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dto;

import java.util.Objects;

/**
 *
 * @author ciclost
 */
public class Direccion {
    
    private int numero;
    private Usuario usuario;
    private String direccion;
    private String poblacion;
    private int cPostal;
    private String comunidad;

    public Direccion(int numero, Usuario usuario, String direccion, String poblacion, int cPostal, String comunidad) {
        this.numero = numero;
        this.usuario = usuario;
        this.direccion = direccion;
        this.poblacion = poblacion;
        this.cPostal = cPostal;
        this.comunidad = comunidad;
    }

    public int getNumero() {
        return numero;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public String getDireccion() {
        return direccion;
    }

    public String getPoblacion() {
        return poblacion;
    }

    public int getcPostal() {
        return cPostal;
    }

    public String getComunidad() {
        return comunidad;
    }
    
    public boolean perteneceA(Usuario u){
        return this.usuario.equals(u);
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public void setPoblacion(String poblacion) {
        this.poblacion = poblacion;
    }

    public void setcPostal(int cPostal) {
        this.cPostal = cPostal;
    }

    public void setComunidad(String comunidad) {
        this.comunidad = comunidad;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 97 * hash + this.numero;
        hash = 97 * hash + Objects.hashCode(this.usuario);
        hash = 97 * hash + Objects.hashCode(this.direccion);
        hash = 97 * hash + Objects.hashCode(this.poblacion);
        hash = 97 * hash + this.cPostal;
        hash = 97 * hash + Objects.hashCode(this.comunidad);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Direccion other = (Direccion) obj;
        if (this.numero != other.numero) {
            return false;
        }
        if (this.cPostal != other.cPostal) {
            return false;
        }
        if (!Objects.equals(this.direccion, other.direccion)) {
            return false;
        }
        if (!Objects.equals(this.poblacion, other.poblacion)) {
            return false;
        }
        if (!Objects.equals(this.usuario, other.usuario)) {
            return false;
        }
        return this.comunidad.equals(other.comunidad);
    }

    @Override
    public String toString() {
        return "Direccion{" + "numero=" + numero + ", usuario=" + usuario + ", direccion=" + direccion + ", poblacion=" + poblacion + ", cPostal=" + cPostal + ", comunidad=" + comunidad + '}';
    }

    

    
    
}
