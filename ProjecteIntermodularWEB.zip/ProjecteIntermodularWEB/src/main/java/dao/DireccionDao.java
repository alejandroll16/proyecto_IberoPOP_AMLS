/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;


import dto.Direccion;
import dto.Usuario;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author ciclost
 */
public class DireccionDao extends TablaDAO<Direccion> {

    public DireccionDao() {
        this.tabla = "PROYECTO_direccion";
    }

    @Override
    public int actualizar(Direccion d) throws SQLException {
        // NO SE UTILIZA EN NUESTRO PROYECTO
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public int anyadir(Direccion d) throws SQLException {
        String sentenciaSQL = "INSERT INTO " + tabla + " VALUES(?,?,?,?,?,?)";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, d.getNumero());
        prepared.setInt(2, d.getUsuario().getCodigo());
        prepared.setString(3, d.getDireccion());
        prepared.setString(4, d.getPoblacion());
        prepared.setInt(5, d.getcPostal());
        prepared.setString(6, d.getComunidad());
        return prepared.executeUpdate();
    }

    @Override
    public Direccion eliminar(Direccion d) throws SQLException {
        if (d == null) {
            return null;
        } else {
            return eliminar(d.getNumero()) != null ? d : null;
        }
    }

    @Override
    public boolean existe(Direccion d) throws SQLException {
        return existe(d.getNumero());
    }

    @Override
    public ArrayList<Direccion> getAll() throws SQLException {
        ArrayList<Direccion> lista = new ArrayList<>();
        String sentenciaSQL = "SELECT * FROM " + tabla + " ORDER BY numero";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            int numero = resultSet.getInt("numero");
            Usuario usuario = new UsuarioDao().getByCodigo(resultSet.getInt("usuario"));
            String direccion = resultSet.getString("direccion");
            String poblacion = resultSet.getString("poblacion");
            int cPostal = resultSet.getInt("c_postal");
            String  comunidad = resultSet.getString("c_autonoma");
            lista.add(new Direccion(numero, usuario, direccion, poblacion, cPostal,comunidad));
        }
        return lista;
    }
    
    

    @Override
    public Direccion getByCodigo(int numero) throws SQLException {
        String sentenciaSQL = "SELECT * FROM " + tabla + " WHERE numero=?";;
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, numero);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
             Usuario usuario = new UsuarioDao().getByCodigo(resultSet.getInt("usuario"));
            String direccion = resultSet.getString("direccion");
            String poblacion = resultSet.getString("poblacion");
            int cPostal = resultSet.getInt("c_postal");
            String  comunidad = resultSet.getString("c_autonoma");
            return new Direccion(numero, usuario, direccion, poblacion, cPostal,comunidad);
        }
        return null;
    }
    
     public ArrayList<Direccion> getDireccionesDe(Usuario u) throws SQLException {
        ArrayList<Direccion> lista = new ArrayList<>();
        String sentenciaSQL = "SELECT * FROM " + tabla + " WHERE usuario=? ";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, u.getCodigo());
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            int numero = resultSet.getInt("numero");
            Usuario usuario = new UsuarioDao().getByCodigo(resultSet.getInt("usuario"));
            String direccion = resultSet.getString("direccion");
            String poblacion = resultSet.getString("poblacion");
            int cPostal = resultSet.getInt("c_postal");
            String  comunidad = resultSet.getString("c_autonoma");
            lista.add(new Direccion(numero, usuario, direccion, poblacion, cPostal,comunidad));
        }
        return lista;
    }



}