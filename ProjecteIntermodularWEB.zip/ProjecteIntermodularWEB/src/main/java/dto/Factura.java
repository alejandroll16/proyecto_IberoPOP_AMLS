 /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dto;

import java.time.LocalDateTime;
import java.util.Objects;

/**
 *
 * @author ciclost
 */
public class Factura {
    
    private int codigo;
    private Pedido unPedido; //Creamos el atributo unPedido para relacionar directamente la factura con su pedido correspondiente.
    private Direccion direcFactura; //Al igual que en la clase direccion.
    private LocalDateTime fecha;



    public Factura(int codigo, LocalDateTime fecha, Direccion direcFactura, Pedido unPedido) {
        this.codigo = codigo;
        this.fecha = fecha;
        this.direcFactura = direcFactura;
        this.unPedido = unPedido;
    }

    public int getCodigo() {
        return codigo;
    }

    public LocalDateTime getFecha() {
        return fecha;
    }

    public Direccion getDirecFactura() {
        return direcFactura;
    }

    public Pedido getUnPedido() {
        return unPedido;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public void setFecha(LocalDateTime fecha) {
        this.fecha = fecha;
    }

    public void setDirecFactura(Direccion direcFactura) {
        this.direcFactura = direcFactura;
    }

    public void setUnPedido(Pedido unPedido) {
        this.unPedido = unPedido;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 37 * hash + this.codigo;
        hash = 37 * hash + Objects.hashCode(this.fecha);
        hash = 37 * hash + Objects.hashCode(this.direcFactura);
        hash = 37 * hash + Objects.hashCode(this.unPedido);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Factura other = (Factura) obj;
        if (this.codigo != other.codigo) {
            return false;
        }
        if (!Objects.equals(this.fecha, other.fecha)) {
            return false;
        }
        if (!Objects.equals(this.direcFactura, other.direcFactura)) {
            return false;
        }
        return Objects.equals(this.unPedido, other.unPedido);
    }

    @Override
    public String toString() {
        return "Factura{" + "codigo=" + codigo + ", fecha=" + fecha + ", direcFactura=" + direcFactura + ", unPedido=" + unPedido + '}';
    }

    

    
    
}
