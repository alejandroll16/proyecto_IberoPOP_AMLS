/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package dto;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 *
 * @author ciclost
 */
public class Usuario {
    
    private int codigo;
    private String email;
    private String nombreApellido;
    private String contr;
    private int telefono;
    private LocalDateTime fNacimiento;
    private LocalDateTime ultimaConexion;
    private TipoUsuarios tipoUsuario;

    public Usuario(int codigo, String nombreApellido, String contr, int telefono, LocalDateTime fNacimiento, String email, LocalDateTime ultimaConexion, TipoUsuarios tipoUsuario) {
        this.codigo = codigo;
        this.nombreApellido = nombreApellido;
        this.contr = contr;
        this.telefono = telefono;
        this.fNacimiento = fNacimiento;
        this.email = email;
        this.ultimaConexion = ultimaConexion;
        this.tipoUsuario = (tipoUsuario == null) ? TipoUsuarios.Anonimo : tipoUsuario;
    }
    

    public int getCodigo() {
        return codigo;
    }

    public String getNombreApellido() {
        return nombreApellido;
    }

    public String getContr() {
        return contr;
    }

    public int getTelefono() {
        return telefono;
    }

    public LocalDateTime getfNacimiento() {
        return fNacimiento;
    }

    public String getEmail() {
        return email;
    }

    public LocalDateTime getUltimaConexion() {
        return ultimaConexion;
    }

    public TipoUsuarios getTipoUsuario() {
        return tipoUsuario;
    }

     public boolean isAdmin(){
        return tipoUsuario == TipoUsuarios.Admin;
    }
    
     public boolean isCliente(){
        return tipoUsuario == TipoUsuarios.Cliente;
    }
     
     public boolean isAnonimo(){
        return tipoUsuario == TipoUsuarios.Anonimo;
    }
     
     public List<Direccion> getListaDirecciones(List<Direccion> original) {
        List<Direccion> lista = new ArrayList<>();
        for (Direccion d : original) {
            if (d.perteneceA(this)) {
                lista.add(d);
            }
        }
        return lista;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 59 * hash + this.codigo;
        hash = 59 * hash + Objects.hashCode(this.nombreApellido);
        hash = 59 * hash + Objects.hashCode(this.contr);
        hash = 59 * hash + this.telefono;
        hash = 59 * hash + Objects.hashCode(this.fNacimiento);
        hash = 59 * hash + Objects.hashCode(this.email);
        hash = 59 * hash + Objects.hashCode(this.ultimaConexion);
        hash = 59 * hash + Objects.hashCode(this.tipoUsuario);
        
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Usuario other = (Usuario) obj;
        return this.codigo == other.codigo;
    }

    @Override
    public String toString() {
        return "Usuario{" + "codigo=" + codigo + ", nombreApellido=" + nombreApellido + ", contr=" + contr + ", telefono=" + telefono + ", fNacimiento=" + fNacimiento + ", email=" + email + ", ultimaConexion=" + ultimaConexion + ", tipoUsuario=" + tipoUsuario + '}';
    }

    
        
     

    
    
}
