/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import dto.Direccion;
import dto.Factura;
import dto.Pedido;
import dto.TipoPago;
import java.sql.SQLException;
import java.time.LocalDateTime;


/**
 *
 * @author ciclost
 */
public class Pruebas {

    public static void main(String[] args) throws SQLException {

        DireccionDao direccion = new DireccionDao();
       UsuarioDao usuario = new UsuarioDao();
        ProductosDao producto = new ProductosDao();
        CategoriasDao categorias = new CategoriasDao();
        PedidoDao pedido = new PedidoDao();
        FacturaDao factura = new FacturaDao();
        
        
       
        /*System.out.println(producto.getAll());
        System.out.println(direccion.getAll());
        System.out.println(usuario.getAll());
        System.out.println(categorias.getAll()); */   
        
    }
}
