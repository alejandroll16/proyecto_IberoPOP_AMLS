/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;



import dto.TipoUsuarios;
import dto.Usuario;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;


/**
 *
 * @author ciclost
 */
public class UsuarioDao extends TablaDAO<Usuario> {
    
    public UsuarioDao() {
        this.tabla = "PROYECTO_usuario";
    }

    @Override
    public int actualizar(Usuario u) {
        // NO SE UTILIZA EN NUESTRO PROYECTO
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public int anyadir(Usuario u) throws SQLException {
        String sentenciaSQL = "INSERT INTO " + tabla + " VALUES(?,?,?,?,?,?,?,?,?)";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, u.getCodigo());
        prepared.setString(2, u.getEmail());
        prepared.setString(3, u.getNombreApellido());
        prepared.setString(4, u.getContr());
        prepared.setInt(5, u.getTelefono());
        LocalDateTime fNacimiento = u.getfNacimiento();
        if (fNacimiento == null){
            prepared.setNull(6, java.sql.Types.TIMESTAMP);
        } else { 
            prepared.setTimestamp(6, Timestamp.valueOf(fNacimiento));            
        }
        LocalDateTime ultimaConexion = u.getUltimaConexion();
        if (ultimaConexion == null) {
            prepared.setNull(7, java.sql.Types.TIMESTAMP);
        } else {
            prepared.setTimestamp(8, Timestamp.valueOf(ultimaConexion));
        }
        prepared.setString(9, String.valueOf(u.getTipoUsuario()));
        return 0;
        
    }

    @Override
    public Usuario eliminar(Usuario u) throws SQLException {
        if (u == null) {
            return null;
        } else {
            return eliminar(u.getCodigo()) != null ? u : null;
        }
    }

    @Override
    public boolean existe(Usuario u) throws SQLException {
        return existe(u.getCodigo());
    }


    @Override
    public ArrayList<Usuario> getAll() throws SQLException {
        ArrayList<Usuario> lista = new ArrayList<>();
        String sentenciaSQL = "SELECT * FROM " + tabla + " ORDER BY codigo";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            int codigo = resultSet.getInt("codigo");
            String nombreApellido = resultSet.getString("nombre_Apellidos");
            String contr = resultSet.getString("contr");
            int telefono = resultSet.getInt("tel");
            LocalDateTime fNacimiento = resultSet.getTimestamp("fNacimiento").toLocalDateTime();
            String email = resultSet.getString("email");                 
            Timestamp ultimaConexionTS = resultSet.getTimestamp("ult_conex");
            LocalDateTime ultimaConexion = ultimaConexionTS == null ? null : ultimaConexionTS.toLocalDateTime();
            TipoUsuarios tipoUsuario = TipoUsuarios.valueOf(resultSet.getString("tipo_Usuario"));
            
            lista.add(new Usuario(codigo, nombreApellido, contr, telefono, fNacimiento, email, ultimaConexion, tipoUsuario));
        }

        return lista;
    }
    @Override
    public Usuario getByCodigo(int codigo) throws SQLException {
        String sentenciaSQL = "SELECT * FROM " + tabla + " WHERE codigo=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, codigo);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            String nombreApellido = resultSet.getString("nombre_Apellidos");
            String contr = resultSet.getString("contr");
            int telefono = resultSet.getInt("tel");
            LocalDateTime fNacimiento = resultSet.getTimestamp("fNacimiento").toLocalDateTime();
            String email = resultSet.getString("email");                 
            Timestamp ultimaConexionTS = resultSet.getTimestamp("ult_conex");
            LocalDateTime ultimaConexion = ultimaConexionTS == null ? null : ultimaConexionTS.toLocalDateTime();
            TipoUsuarios tipoUsuario = TipoUsuarios.valueOf(resultSet.getString("tipo_Usuario"));
            
            return new Usuario(codigo, nombreApellido, contr, telefono, fNacimiento, email, ultimaConexion, tipoUsuario);
        }
        
        return null;
    }
    
    
        
    public Usuario validar(String formEmail, String formPassword) throws SQLException {
        String sentenciaSQL = "SELECT * FROM " + tabla + " WHERE email=? AND contr=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setString(1, formEmail);
        prepared.setString(2, formPassword);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            int codigo = resultSet.getInt("codigo");
            String nombreApellido = resultSet.getString("nombre_Apellidos");
            String contr = resultSet.getString("contr");
            int telefono = resultSet.getInt("tel");
            LocalDateTime fNacimiento = resultSet.getTimestamp("fNacimiento").toLocalDateTime();
            String email = resultSet.getString("email");                 
            Timestamp ultimaConexionTS = resultSet.getTimestamp("ult_conex");
            LocalDateTime ultimaConexion = ultimaConexionTS == null ? null : ultimaConexionTS.toLocalDateTime();
            TipoUsuarios tipoUsuario = TipoUsuarios.valueOf(resultSet.getString("tipo_Usuario"));
            
            return new Usuario(codigo, nombreApellido, contr, telefono, fNacimiento, email, ultimaConexion, tipoUsuario);
        }
        
        return null;
    }
    
}
