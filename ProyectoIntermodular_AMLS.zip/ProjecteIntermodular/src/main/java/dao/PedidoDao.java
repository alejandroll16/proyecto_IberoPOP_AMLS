/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import dto.Direccion;
import dto.Linea_Pedido;
import dto.Pedido;
import dto.Productos;
import dto.TipoPago;
import dto.Usuario;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;



/**
 *
 * @author aleja
 */
public class PedidoDao extends TablaDAO<Pedido> {
    public PedidoDao() {
        this.tabla = "PROYECTO_pedido";
    }

    @Override
    public int actualizar(Pedido p) throws SQLException {
        //No necesario para el proyecto
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public int anyadir(Pedido p) throws SQLException {
        String sentenciaSQL = "INSERT INTO " + tabla + " VALUES(?,?,?,?,?,?,?)";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, p.getCodigo());
        Usuario usuario = p.getUsuario();
        if (usuario == null) {
            prepared.setNull(2, java.sql.Types.INTEGER);
        } else {
            prepared.setInt(2, usuario.getCodigo());
        }
        Direccion usuario_direct = p.getUsuario_direct();
        if (usuario_direct == null) {
            prepared.setNull(2, java.sql.Types.INTEGER);
        } else {
            prepared.setInt(2, usuario_direct.getNumero());
        }
                      
        LocalDateTime fecha = p.getFecha();
        if (fecha == null){
            prepared.setNull(5, java.sql.Types.TIMESTAMP);
        } else { 
            prepared.setTimestamp(5, Timestamp.valueOf(fecha));            
        }
        prepared.setDouble(6, p.getPrecioTotal());
        
        prepared.setString(7, p.getTipo_pago().toString());
        
        int resultado = prepared.executeUpdate();
        anyadirLinea(p);
        return resultado;
        
        
    }

    @Override
    public Pedido eliminar(Pedido p) throws SQLException {
        if (p == null) {
            return null;
        } else {
            return eliminar(p.getCodigo()) != null ? p : null;
        }
    }

    @Override
    public boolean existe(Pedido p) throws SQLException {
        return existe(p.getCodigo());
    }

    @Override
    public ArrayList<Pedido> getAll() throws SQLException {
        ArrayList<Pedido> lista = new ArrayList<>();
        String sentenciaSQL = "SELECT * FROM " + tabla + " ORDER BY codigo";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            int codigo = resultSet.getInt("codigo");
            Usuario usuario = new UsuarioDao().getByCodigo(resultSet.getInt("usuario"));
            Direccion usuario_direct = new DireccionDao().getByCodigo(resultSet.getInt("usuario_direc"));
            LocalDateTime fecha = resultSet.getTimestamp("fecha").toLocalDateTime();
            double precioTotal = resultSet.getDouble("precio_total");
            TipoPago tipoPago = TipoPago.valueOf(resultSet.getString("tipo_pago"));
            
            lista.add(new Pedido(codigo, usuario, usuario_direct ,fecha, precioTotal, tipoPago, getLineas(codigo)));
        }

        return lista;
    }

    @Override
    public Pedido getByCodigo(int codigo) throws SQLException {
        String sentenciaSQL = "SELECT * FROM " + tabla + " WHERE codigo=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, codigo);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            Usuario usuario = new UsuarioDao().getByCodigo(resultSet.getInt("usuario"));
            Direccion usuario_direct = new DireccionDao().getByCodigo(resultSet.getInt("usuario_direc"));
            LocalDateTime fecha = resultSet.getTimestamp("fecha").toLocalDateTime();
            double precioTotal = resultSet.getDouble("precio_total");
            TipoPago tipoPago = TipoPago.valueOf(resultSet.getString("tipo_pago"));
            return new Pedido(codigo, usuario, usuario_direct ,fecha, precioTotal, tipoPago, getLineas(codigo));
        }

        return null;
    }
    
    public ArrayList<Linea_Pedido> getLineas(int codPedido) throws SQLException{
        ProductosDao productoDao = new ProductosDao();
        ArrayList<Linea_Pedido> lineasCesta = new ArrayList<>();
        String sentenciaSQL = "SELECT producto, cantidad , precio_producto FROM PROYECTO_linea_pedido WHERE pedido = ?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, codPedido);
        ResultSet resultSet = prepared.executeQuery();
        while (resultSet.next()) {
            Productos productos = productoDao.getByCodigo(resultSet.getInt("producto"));
            int cantidad = resultSet.getInt("cantidad");
            double precioProducto = resultSet.getDouble("precio_producto");
            lineasCesta.add(new Linea_Pedido(productos, cantidad, precioProducto));
        }
        return lineasCesta;
    }
    
    private void anyadirLinea(Pedido p) throws SQLException {
        for (Linea_Pedido l : p.getProductos()) {
            String sentenciaSQL = "INSERT INTO PROYECTO_linea_pedido VALUES(?, ?, ?, ?, ?)";
            PreparedStatement prepared = getPrepared(sentenciaSQL);
            prepared.setInt(1, l.getProducto().getCodigo());
            prepared.setInt(2, p.getCodigo());
            prepared.setInt(3, p.getUsuario().getCodigo());
            prepared.setDouble(4, l.getPrecioProducto());
            prepared.setInt(5, l.getCantidad());
            prepared.executeUpdate();
        }
    }
    
    public ArrayList<Pedido> getByCodigoUsuario(int codigoUsuario) throws SQLException {
        ArrayList<Pedido> pedidos = new ArrayList<>();
        String sentenciaSQL = "SELECT * FROM " + tabla + " WHERE usuario=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, codigoUsuario);
        ResultSet resultSet = prepared.executeQuery();
        Usuario usuario = new UsuarioDao().getByCodigo(codigoUsuario);
        while (resultSet.next()) {
            int codigo = resultSet.getInt("codigo");
            Direccion usuario_direct = new DireccionDao().getByCodigo(resultSet.getInt("usuario_direct"));
            LocalDateTime fecha = resultSet.getTimestamp("fecha").toLocalDateTime();
            double precioTotal = resultSet.getDouble("precio_total");
            TipoPago tipoPago = TipoPago.valueOf(resultSet.getString("tipo_pago"));
            
            pedidos.add(new Pedido(codigo, usuario, usuario_direct ,fecha, precioTotal, tipoPago, getLineas(codigo)));
        }

        return pedidos;
    }   
    
    

    private void eliminarLineas(Pedido p) throws SQLException {
        String sentenciaSQL = "DELETE FROM PROYECTO_linea_pedido WHERE pedido=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, p.getCodigo());
        prepared.executeUpdate();

    }

   

    

    public boolean estaFacturado(int codpedido) throws SQLException {
        String sentenciaSQL = "SELECT * FROM factura WHERE pedido=?";
        PreparedStatement prepared = getPrepared(sentenciaSQL);
        prepared.setInt(1, codpedido);
        return prepared.executeUpdate() != 0;

    }
}
