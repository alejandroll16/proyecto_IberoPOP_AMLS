/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dto;

import java.util.Objects;

/**
 *
 * @author ciclost
 */
public class Linea_Pedido {
    
    private Productos producto; //Hacemos uso de la clase producto para saber que producto estamos seleccionando.
    private int cantidad;
    private double precioProducto;

    public Linea_Pedido(Productos producto, int cantidad, double precioProducto) {
        this.producto = producto;
        this.cantidad = cantidad;
        this.precioProducto = precioProducto;
    }

    public Productos getProducto() {
        return producto;
    }

  

    public int getCantidad() {
        return cantidad;
    }

    public double getPrecioProducto() {
        return precioProducto;
    }

    public void setProducto(Productos producto) {
        this.producto = producto;
    }

   

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public void setPrecioProducto(double precioProducto) {
        this.precioProducto = precioProducto;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 79 * hash + Objects.hashCode(this.producto);
       
        hash = 79 * hash + this.cantidad;
        hash = 79 * hash + (int) (Double.doubleToLongBits(this.precioProducto) ^ (Double.doubleToLongBits(this.precioProducto) >>> 32));
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Linea_Pedido other = (Linea_Pedido) obj;
        if (this.cantidad != other.cantidad) {
            return false;
        }
        if (Double.doubleToLongBits(this.precioProducto) != Double.doubleToLongBits(other.precioProducto)) {
            return false;
        }
        return Objects.equals(this.producto, other.producto);
    }

    

    @Override
    public String toString() {
        return "Linea_Pedido{" + "producto=" + producto +  ", cantidad=" + cantidad + ", precioProducto=" + precioProducto + '}';
    }

    
    
    
}
