/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package dto;

import java.time.LocalDateTime;
import java.util.Objects;

/**
 *
 * @author ciclost
 */
public class Usuario {
    
    private int codigo;
    private String nombreApellido;
    private String contr;
    private int telefono;
    private LocalDateTime fNacimiento;
    private String email;
    private LocalDateTime ultimaConexion;
    private TipoUsuarios tipoUsuario;
    

    public Usuario(int codigo, String nombreApellido, String contr, int telefono, LocalDateTime fNacimiento, String email, LocalDateTime ultimaConexion, TipoUsuarios tipoUsuario) {
        this.codigo = codigo;
        this.nombreApellido = nombreApellido;
        this.contr = contr;
        this.telefono = telefono;
        this.fNacimiento = fNacimiento;
        this.email = email;
        this.ultimaConexion = ultimaConexion;
        this.tipoUsuario = tipoUsuario;
        
    }

    public int getCodigo() {
        return codigo;
    }

    public String getNombreApellido() {
        return nombreApellido;
    }

    public String getContr() {
        return contr;
    }

    public int getTelefono() {
        return telefono;
    }

    public LocalDateTime getfNacimiento() {
        return fNacimiento;
    }

    public String getEmail() {
        return email;
    }

    public LocalDateTime getUltimaConexion() {
        return ultimaConexion;
    }

    public TipoUsuarios getTipoUsuario() {
        return tipoUsuario;
    }


    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public void setNombreApellido(String nombreApellido) {
        this.nombreApellido = nombreApellido;
    }

    public void setContraseña(String contraseña) {
        this.contr = contraseña;
    }

    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    public void setfNacimiento(LocalDateTime fNacimiento) {
        this.fNacimiento = fNacimiento;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setUltimaConexion(LocalDateTime ultimaConexion) {
        this.ultimaConexion = ultimaConexion;
    }

    public void setTipoUsuario(TipoUsuarios tipoUsuario) {
        this.tipoUsuario = tipoUsuario;
    }



    @Override
    public int hashCode() {
        int hash = 5;
        hash = 59 * hash + this.codigo;
        hash = 59 * hash + Objects.hashCode(this.nombreApellido);
        hash = 59 * hash + Objects.hashCode(this.contr);
        hash = 59 * hash + this.telefono;
        hash = 59 * hash + Objects.hashCode(this.fNacimiento);
        hash = 59 * hash + Objects.hashCode(this.email);
        hash = 59 * hash + Objects.hashCode(this.ultimaConexion);
        hash = 59 * hash + Objects.hashCode(this.tipoUsuario);
        
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Usuario other = (Usuario) obj;
        if (this.codigo != other.codigo) {
            return false;
        }
        if (this.telefono != other.telefono) {
            return false;
        }
        if (!Objects.equals(this.nombreApellido, other.nombreApellido)) {
            return false;
        }
        if (!Objects.equals(this.contr, other.contr)) {
            return false;
        }
        if (!Objects.equals(this.email, other.email)) {
            return false;
        }
        if (!Objects.equals(this.fNacimiento, other.fNacimiento)) {
            return false;
        }
        if (!Objects.equals(this.ultimaConexion, other.ultimaConexion)) {
            return false;
        }
        return this.tipoUsuario == other.tipoUsuario;
    }

    @Override
    public String toString() {
        return "Usuario{" + "codigo=" + codigo + ", nombreApellido=" + nombreApellido + ", contr=" + contr + ", telefono=" + telefono + ", fNacimiento=" + fNacimiento + ", email=" + email + ", ultimaConexion=" + ultimaConexion + ", tipoUsuario=" + tipoUsuario + '}';
    }

    
        
     

    
    
}
