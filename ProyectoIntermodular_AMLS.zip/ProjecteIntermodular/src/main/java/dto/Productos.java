/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dto;




import java.time.LocalDateTime;
import java.util.Objects;

/**
 *
 * @author ciclost
 */
public class Productos {
    
    private int codigo;
    private Categorias categoria;
    private String nombre;
    private double precio;
    private TipoTamano tamaño;
    private TipoProductos tipoProductos;
    private double IVA;
    private LocalDateTime f_Creac;
    private LocalDateTime f_ult_modificacion;
    private String descrip_Caracteristicas;
    private Usuario modifica;
    private Usuario crea;

    public Productos(int codigo, Categorias categoria, String nombre, double precio, TipoTamano tamaño, TipoProductos tipoProductos, double IVA, LocalDateTime f_Creac, LocalDateTime f_ult_modificacion, String descrip_Caracteristicas, Usuario modifica, Usuario crea) {
        this.codigo = codigo;
        this.categoria = categoria;
        this.nombre = nombre;
        this.precio = precio;
        this.tamaño = tamaño;
        this.tipoProductos = tipoProductos;
        this.IVA = IVA;
        this.f_Creac = f_Creac;
        this.f_ult_modificacion = f_ult_modificacion;
        this.descrip_Caracteristicas = descrip_Caracteristicas;
        this.modifica = modifica;
        this.crea = crea;
    }


    public int getCodigo() {
        return codigo;
    }

    public Categorias getCategoria() {
        return categoria;
    }

    public String getNombre() {
        return nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public TipoTamano getTamaño() {
        return tamaño;
    }

    public TipoProductos getTipoProductos() {
        return tipoProductos;
    }

    public double getIVA() {
        return IVA;
    }

    public LocalDateTime getF_Creac() {
        return f_Creac;
    }

    public LocalDateTime getF_ult_modificacion() {
        return f_ult_modificacion;
    }

    public String getDescrip_Caracteristicas() {
        return descrip_Caracteristicas;
    }

    public Usuario getModifica() {
        return modifica;
    }

    public Usuario getCrea() {
        return crea;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public void setCategoria(Categorias categoria) {
        this.categoria = categoria;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public void setTamaño(TipoTamano tamaño) {
        this.tamaño = tamaño;
    }

    public void setTipoProductos(TipoProductos tipoProductos) {
        this.tipoProductos = tipoProductos;
    }

    public void setIVA(double IVA) {
        this.IVA = IVA;
    }

    public void setF_Creac(LocalDateTime f_Creac) {
        this.f_Creac = f_Creac;
    }

    public void setF_ult_modificacion(LocalDateTime f_ult_modificacion) {
        this.f_ult_modificacion = f_ult_modificacion;
    }

    public void setDescrip_Caracteristicas(String descrip_Caracteristicas) {
        this.descrip_Caracteristicas = descrip_Caracteristicas;
    }

    public void setModifica(Usuario modifica) {
        this.modifica = modifica;
    }

    public void setCrea(Usuario crea) {
        this.crea = crea;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 97 * hash + this.codigo;
        hash = 97 * hash + Objects.hashCode(this.categoria);
        hash = 97 * hash + Objects.hashCode(this.nombre);
        hash = 97 * hash + (int) (Double.doubleToLongBits(this.precio) ^ (Double.doubleToLongBits(this.precio) >>> 32));
        hash = 97 * hash + Objects.hashCode(this.tamaño);
        hash = 97 * hash + Objects.hashCode(this.tipoProductos);
        hash = 97 * hash + (int) (Double.doubleToLongBits(this.IVA) ^ (Double.doubleToLongBits(this.IVA) >>> 32));
        hash = 97 * hash + Objects.hashCode(this.f_Creac);
        hash = 97 * hash + Objects.hashCode(this.f_ult_modificacion);
        hash = 97 * hash + Objects.hashCode(this.descrip_Caracteristicas);
        hash = 97 * hash + Objects.hashCode(this.modifica);
        hash = 97 * hash + Objects.hashCode(this.crea);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Productos other = (Productos) obj;
        if (this.codigo != other.codigo) {
            return false;
        }
        if (Double.doubleToLongBits(this.precio) != Double.doubleToLongBits(other.precio)) {
            return false;
        }
        if (Double.doubleToLongBits(this.IVA) != Double.doubleToLongBits(other.IVA)) {
            return false;
        }
        if (!Objects.equals(this.nombre, other.nombre)) {
            return false;
        }
        if (!Objects.equals(this.descrip_Caracteristicas, other.descrip_Caracteristicas)) {
            return false;
        }
        if (!Objects.equals(this.categoria, other.categoria)) {
            return false;
        }
        if (this.tamaño != other.tamaño) {
            return false;
        }
        if (this.tipoProductos != other.tipoProductos) {
            return false;
        }
        if (!Objects.equals(this.f_Creac, other.f_Creac)) {
            return false;
        }
        if (!Objects.equals(this.f_ult_modificacion, other.f_ult_modificacion)) {
            return false;
        }
        if (!Objects.equals(this.modifica, other.modifica)) {
            return false;
        }
        return Objects.equals(this.crea, other.crea);
    }

    @Override
    public String toString() {
        return "Productos{" + "codigo=" + codigo + ", categoria=" + categoria + ", nombre=" + nombre + ", precio=" + precio + ", tama\u00f1o=" + tamaño + ", tipoProductos=" + tipoProductos + ", IVA=" + IVA + ", f_Creac=" + f_Creac + ", f_ult_modificacion=" + f_ult_modificacion + ", descrip_Caracteristicas=" + descrip_Caracteristicas + ", modifica=" + modifica + ", crea=" + crea + '}';
    }

    

    

    

    

    
    
    
}
