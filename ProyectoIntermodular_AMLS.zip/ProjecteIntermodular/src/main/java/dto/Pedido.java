/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dto;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Objects;

/**
 *
 * @author ciclost
 */
public class Pedido {
    
    private int codigo;
    private Usuario usuario;
    private Direccion usuario_direct;
    private LocalDateTime fecha;
    private double precioTotal;
    private TipoPago tipo_pago;
    private ArrayList<Linea_Pedido> productos;

    public Pedido(int codigo, Usuario usuario, Direccion usuario_direct, LocalDateTime fecha, double precioTotal, TipoPago tipo_pago, ArrayList<Linea_Pedido> productos) {
        this.codigo = codigo;
        this.usuario = usuario;
        this.usuario_direct = usuario_direct;
        this.fecha = fecha;
        this.precioTotal = precioTotal;
        this.tipo_pago = tipo_pago;
        this.productos = productos;
    }

    public int getCodigo() {
        return codigo;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public Direccion getUsuario_direct() {
        return usuario_direct;
    }

    public LocalDateTime getFecha() {
        return fecha;
    }

    public double getPrecioTotal() {
        return precioTotal;
    }

    public TipoPago getTipo_pago() {
        return tipo_pago;
    }

    public ArrayList<Linea_Pedido> getProductos() {
        return productos;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public void setUsuario_direct(Direccion usuario_direct) {
        this.usuario_direct = usuario_direct;
    }

    public void setFecha(LocalDateTime fecha) {
        this.fecha = fecha;
    }

    public void setPrecioTotal(double precioTotal) {
        this.precioTotal = precioTotal;
    }

    public void setTipo_pago(TipoPago tipo_pago) {
        this.tipo_pago = tipo_pago;
    }

    public void setProductos(ArrayList<Linea_Pedido> productos) {
        this.productos = productos;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 79 * hash + this.codigo;
        hash = 79 * hash + Objects.hashCode(this.usuario);
        hash = 79 * hash + Objects.hashCode(this.usuario_direct);
        hash = 79 * hash + Objects.hashCode(this.fecha);
        hash = 79 * hash + (int) (Double.doubleToLongBits(this.precioTotal) ^ (Double.doubleToLongBits(this.precioTotal) >>> 32));
        hash = 79 * hash + Objects.hashCode(this.tipo_pago);
        hash = 79 * hash + Objects.hashCode(this.productos);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Pedido other = (Pedido) obj;
        if (this.codigo != other.codigo) {
            return false;
        }
        if (Double.doubleToLongBits(this.precioTotal) != Double.doubleToLongBits(other.precioTotal)) {
            return false;
        }
        if (!Objects.equals(this.usuario, other.usuario)) {
            return false;
        }
        if (!Objects.equals(this.usuario_direct, other.usuario_direct)) {
            return false;
        }
        if (!Objects.equals(this.fecha, other.fecha)) {
            return false;
        }
        if (this.tipo_pago != other.tipo_pago) {
            return false;
        }
        return Objects.equals(this.productos, other.productos);
    }

    @Override
    public String toString() {
        return "Pedido{" + "codigo=" + codigo + ", usuario=" + usuario + ", usuario_direct=" + usuario_direct + ", fecha=" + fecha + ", precioTotal=" + precioTotal + ", tipo_pago=" + tipo_pago + ", productos=" + productos + '}';
    }

   

    
        

        
    
    
}
